from django.contrib import admin
from .models import Human


admin.site.register(Human)
# Register your models here.
